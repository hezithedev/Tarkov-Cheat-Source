﻿namespace Swoopie
{
    class Settings
    {
        public static string GAME_NAME = "escapefromtarkov";
        public static string USERNAME = "Zeziroth";
    }
}
