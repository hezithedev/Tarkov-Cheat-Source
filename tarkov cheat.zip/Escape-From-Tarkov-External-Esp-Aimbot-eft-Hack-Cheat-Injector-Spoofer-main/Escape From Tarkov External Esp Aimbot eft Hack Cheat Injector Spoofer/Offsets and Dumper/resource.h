//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by EFT Leecher.rc
//
#define IDD_MAIN_DIALOG                 101
#define IDD_SERIAL_DIALOG               103
#define IDD_SKILL_BUF_DIALOG            105
#define ID_BTN_DMA_SHUTDOWN             1001
#define ID_BTN_DMA_CONNECT              1002
#define ID_BTN_VISOR_EFFECT             1003
#define ID_BTN_NIGHTVISION_ON           1004
#define ID_BTN_NIGHTVISION              1004
#define ID_BTN_NIGHTVISION_OFF          1005
#define IDC_NOWEIGHT                    1006
#define ID_BTN_THERMAL_ON               1007
#define ID_BTN_THERMAL_OFF              1008
#define ID_BTN_THERMAL                  1008
#define IDC_DOORS                       1009
#define ID_EXIT                         1010
#define IDC_HWID                        1011
#define IDC_DOORS_KEYCARD               1012
#define IDC_NORECOIL                    1013
#define IDC_STATUS_TEXT                 1013
#define IDC_ENDURANCE                   1014
#define IDC_SKILLSMAX                   1015
#define IDC_EDIT1                       1015
#define IDC_SERIAL                      1015
#define IDC_SKILLS_MAX                  1015
#define IDC_REMOVE_CONNECTIONS          1016
#define IDC_USE_MMAP_FILE               1017
#define IDC_USE_STEALTH_CONNECTION      1018
#define IDC_CONNECTION_STATUS           1019
#define IDC_PROCESS_ID                  1020
#define IDC_CHECK1                      1021
#define IDC_SKILL_BUFFER                1021
#define IDC_AIMBOT_ENABLE               1021
#define IDC_AUTO_DISCONNECT             1022
#define IDC_BTN_SKILLS                  1023
#define IDC_PLAYER_STATUS               1024
#define IDC_WORLD_STATUS                1025
#define IDC_STATUS_LOCATION             1026
#define IDC_SKILLS_LIST                 1027
#define IDC_SLIDER1                     1028
#define IDC_LEVEL_SLIDER                1028
#define IDC_JUMP_SLIDER                 1028
#define IDC_THROW_SLIDER                1029
#define IDC_ENABLE_LEVEL                1030
#define IDC_HEARING_SLIDER              1030
#define IDC_LEVEL_TEXT                  1031
#define IDC_JUMP_TEXT                   1036
#define IDC_THROW_TEXT                  1037
#define IDC_HEARING_TEXT                1038
#define IDC_AIMBOT_HEAD                 1039
#define IDC_AIMBOT_CHEST                1040
#define IDC_AIMBOT_PELVIS               1041
#define IDC_AIMBOT_KEY                  1042
#define IDC_AIMBOT_HOTKEY               1042
#define IDC_AIMBOT_LFOOT                1043
#define IDC_AIMBOT_RFOOT                1044
#define IDC_AIMBOT_RANDOM               1045
#define IDC_RADIO3                      1048

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1049
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
