###  Escape-From-Tarkov Aimbot + Esp C++ 
![GitHub release](https://img.shields.io/github/release/ppy/osu.svg)
![CodeFactor](https://www.codefactor.io/repository/github/ppy/osu/badge)
![dev chat](https://discordapp.com/api/guilds/188630481301012481/widget.png?style=shield)
![Crowdin](https://d322cqt584bo4o.cloudfront.net/osu-web/localized.svg)
![Renovate enabled](https://img.shields.io/badge/renovate-enabled-brightgreen.svg)
![license](https://img.shields.io/github/license/mashape/apistatus.svg)
![Chat](https://badges.gitter.im/awesome-twitter-bots/Lobby.svg)

```sh-session
"Escape-From-Tarkov" RELEASE C++,C / AIMBOT / ESP / SPOOFER / DRIVER / Injector
```
***
<p align="center">
   <img src="https://readme-spotify-status-rho.vercel.app/api/run-spotify-status.py" alt="s4nx Playing Now" width="500" />
<p align="center">

## Information
**External Game Project written mostly in C++ along with external libraries Internal And External projects.I started to get rid of scammers.i am developing Hack Cheat Driver Esp Aimbot Magic Bullet Driver Injector Overlay Imgui for many games.Games I've developed with hack so far Rise Online ,Apex Legends ,Bloodhunt , Call of Duty: Cold War , Call of Duty: Vanguard ,Call of Duty: Warzone/MW ,Dayz ,Dead By Daylight ,Destiny 2 ,Enlisted ,Escape From Tarkov ,Fortnite ,Game accounts ,Halo Infinite ,HyperFlick ,New Critical Hit ,New World ,Mir 4 ,Noble ,Playerunknowns Battlegrounds ,Steam ,Rainbow Siz Siege , Playerunknown's Battlegrounds, Rijin ,Rogue Company ,Rust ,Scum ,SpliteGa ,Super People ,Unleashed ,Valorant ,Spoofer ::: Buying a Hack Cheat don't be scammed, more to come**

There are EFT wallhacks, aimbots, ESPs, No recoil and much more that will make you invincible. If you want to guarantee the best loot, you got it. If you want to be a winner every match, it’s all yours. If you think enemies are hiding around the corner, they won’t know what’s about to hit them.The game has several zones, including the Factory, Woods, Shoreline, the Interchange, Customs, Lab, and Reserves, and if there’s one thing they all have one thing in common, it’s non stop action. What sets this game apart from the rest is the epic survival elements mixed with its intense resource management. 

**Updated Time 17/05/2022**



![image](https://user-images.githubusercontent.com/105746452/169082235-b00ad770-64af-42df-af89-4cc08dc95c44.png)
## Features
<details>
<summary>Features (Drop Down)</summary>
  
* **AIMBOT**
  
* **ESP**
  
* **SPOOFER** 

* **DRIVER**

*  **INJECTOR**
  </details>

**Aimbot**

* Aim Prediction
* * Aim Key
* Head Lock

**Visuals**

* Player ESP
* Scav ESP
* Scav Boss ESP
* Skeleton
* Box
* Visibility Checks
* Health ESP
* Player Weapon + Ammo Count
* Player ESP Distance
* Item ESP
* Medical
* Food
* Valuables
* Keys
* Task
* Ammo
* Attachments
* Other
* Container ESP
* Grenade ESP
* Extraction ESP
* Crosshair
   
**Misc**

* Night Vision
* Thermal Vision
* No Visor
* Infinite Stamina
* Aim Warning
***

## Media 
![image](https://user-images.githubusercontent.com/105746452/169082190-94ac83d4-7d45-485c-b1df-3f785d90462d.png)


## ✨ DONATE Buy Me Coffee

BTC - 144feg2TVeVjhLfXVrKvaTzu2ViX4gYv6q


## Disclaimer
This project is only for educational purposes. Therefore I'm not responsible for any harm/illegal activity that may happens. I made this project to learn more about reverse engineering and not to ruin the experience for other gamers. I will not be updating the offsets for this reason.This may not be exact code as the one in my hackathon.
